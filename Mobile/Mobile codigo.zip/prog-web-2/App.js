// [1] true = mostra os botões de teste (sem servidor). Troque para false para usar 
const MOSTRAR_DEMO = false;

// [2] Endereço da API. TROQUE "SEU_IP_AQUI" pelo IPv4 do PC que roda o uvicorn.
const BASE_URL = "http://40.127.11.169:8000";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, ScrollView, Modal, ActivityIndicator, StyleSheet,
  Platform, RefreshControl, BackHandler, Image, KeyboardAvoidingView, Switch, Dimensions,
} from "react-native";
import { SafeAreaProvider, SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as SecureStore from "expo-secure-store";
import { StatusBar } from "expo-status-bar";


/* ====================== TEMA (igual às telas web) ====================== */
const C = {
  bg: "#111827", bg2: "#030712", surface: "rgba(255,255,255,0.05)", border: "rgba(255,255,255,0.10)",
  text: "#ffffff", soft: "#d1d5db", muted: "#9ca3af", dim: "#6b7280",
  primary: "#6366f1", primaryHi: "#818cf8", primaryBg: "rgba(99,102,241,0.15)",
  danger: "#f87171", dangerBg: "rgba(239,68,68,0.10)", ok: "#4ade80", okBg: "rgba(34,197,94,0.10)",
  warn: "#fbbf24",
};
const STATUS = {
  Pendante: { label: "Pendente", fg: C.warn, bg: "rgba(251,191,36,0.12)" },
  Em_Andamento: { label: "Em andamento", fg: C.primaryHi, bg: C.primaryBg },
  Concluida: { label: "Concluída", fg: C.ok, bg: C.okBg },
};

/* ============================ STORAGE ============================ */
const K = { access: "estok.access", refresh: "estok.refresh", user: "estok.user", login: "estok.login", remember: "estok.remember" };
const store = {
  async get(k) { try { return Platform.OS === "web" ? window.localStorage.getItem(k) : await SecureStore.getItemAsync(k); } catch { return null; } },
  async set(k, v) { try { if (Platform.OS === "web") window.localStorage.setItem(k, v); else await SecureStore.setItemAsync(k, v); } catch {} },
  async del(k) { try { if (Platform.OS === "web") window.localStorage.removeItem(k); else await SecureStore.deleteItemAsync(k); } catch {} },
};

/* ============================ API ============================ */
const S = { access: null, refresh: null, remember: false, onExpire: null, demo: false, demoUser: null };

async function guardarTokens(t) {
  S.access = t.access_token;
  S.refresh = t.refresh_token;
  if (S.remember) await store.set(K.refresh, t.refresh_token);
}

let emRenovacao = null;
async function renovarUnico() {
  if (!S.refresh) return false;
  try {
    const r = await fetch(`${BASE_URL}/refresh`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: S.refresh }),
    });
    if (!r.ok) return false;
    await guardarTokens(await r.json());
    return true;
  } catch { return false; }
}
const renovar = () => emRenovacao ?? (emRenovacao = renovarUnico().finally(() => { emRenovacao = null; }));

function msgErro(data, status) {
  if (data && typeof data.detail === "string") return data.detail;
  if (data && Array.isArray(data.detail)) return data.detail.map((d) => d.msg).join("; ");
  return `Erro ${status}`;
}
const ERRO_REDE = `Não foi possível conectar à API em ${BASE_URL}. Confira o BASE_URL, o Wi-Fi (mesma rede do PC), o firewall (porta 8000) e se o backend está rodando.`;


/* ============================ MODO TESTE (dados fictícios) ============================ */
let DEMO = null;
const clone = (x) => JSON.parse(JSON.stringify(x));
function montarDemo() {
  const it = (id, codigoUnico, nome, loc) => ({ id, codigoUnico, nome, descricao: null, dataCadastro: null, id_localizacao: loc });
  const tf = (id, titulo, descricao, prazo, status, id_usuario) => ({ id, titulo, descricao, dataCadastro: null, prazo, status, id_usuario });
  return {
    usuarios: [
      { id: 1, nome: "Admin Demo", email: "admin@demo.com", perfil: "Admin" },
      { id: 2, nome: "Maria Funcionária", email: "maria@demo.com", perfil: "Funcionario" },
      { id: 3, nome: "João Souza", email: "joao@demo.com", perfil: "Funcionario" },
    ],
    locais: [{ id: 1, nome: "Almoxarifado Central" }, { id: 2, nome: "Sala de TI" }],
    itens: [
      it(1, "ITM-0001", "Notebook Dell", 2), it(2, "ITM-0002", "Monitor 24\"", 2), it(3, "ITM-0003", "Teclado sem fio", 2),
      it(4, "ITM-0004", "Roteador Wi-Fi", 2), it(5, "ITM-0005", "Switch 24 portas", 2), it(6, "ITM-0006", "Cadeira ergonômica", 1),
      it(7, "ITM-0007", "Mesa de reunião", 1), it(8, "ITM-0008", "Projetor", 1), it(9, "ITM-0009", "Impressora laser", 1),
      it(10, "ITM-0010", "Nobreak 1500VA", 1),
    ],
    tarefas: [
      tf(1, "Conferir estoque do almoxarifado", "Contagem mensal", "2026-12-01", "Pendante", 2),
      tf(2, "Inventário da sala de TI", "Equipamentos de rede", "2026-11-20", "Em_Andamento", 2),
      tf(3, "Revisão de monitores", null, "2026-11-10", "Concluida", 2),
      tf(4, "Contagem de cadeiras", "Andar 2", "2026-12-10", "Pendante", 3),
      tf(5, "Auditoria de projetores", null, "2026-12-15", "Pendante", null),
    ],

    vinculos: {
      6: { t: 1, s: "Pendente" }, 7: { t: 1, s: "Pendente" }, 8: { t: 1, s: "Pendente" },
      1: { t: 2, s: "Conferido" }, 4: { t: 2, s: "Pendente" }, 5: { t: 2, s: "Pendente" },
      2: { t: 3, s: "Conferido" }, 3: { t: 4, s: "Pendente" },
    },
  };
}

function entrarDemo(perfil) {
  DEMO = montarDemo();
  const u = DEMO.usuarios.find((x) => x.perfil === perfil);
  S.demo = true; S.demoUser = u; S.access = "demo"; S.refresh = null; S.remember = false;
  return u;
}

async function apiDemo(path, method, body) {
  const D = DEMO;
  const eu = S.demoUser;
  const adm = eu.perfil !== "Funcionario";
  const tarefa = (id) => {
    const t = D.tarefas.find((x) => x.id === Number(id));
    if (!t) throw new Error("Tarefa não encontrada.");
    if (!adm && t.id_usuario !== eu.id) throw new Error("Você só pode acessar tarefas atribuídas a você.");
    return t;
  };
  const itensDa = (tid) => D.itens.filter((i) => D.vinculos[i.id]?.t === tid)
    .map((i) => ({ id: i.id, codigoUnico: i.codigoUnico, nome: i.nome, descricao: i.descricao, status: D.vinculos[i.id].s, dataConferencia: hojeISO() }));
  let m;

  if (method === "GET" && path === "/tarefas/all") return clone(adm ? D.tarefas : D.tarefas.filter((t) => t.id_usuario === eu.id));
  if (method === "GET" && path === "/usuarios/all") return clone(D.usuarios);
  if (method === "GET" && path === "/itens/all") return clone(D.itens);
  if (method === "GET" && path === "/localizacoes/all") return clone(D.locais);

  if (method === "POST" && path === "/tarefas") {
    if (D.tarefas.some((t) => t.titulo === body.titulo)) throw new Error("Já existe uma tarefa com este título.");
    const nova = { id: Math.max(...D.tarefas.map((t) => t.id)) + 1, titulo: body.titulo, descricao: body.descricao, dataCadastro: null, prazo: body.prazo, status: body.status, id_usuario: body.id_usuario };
    D.tarefas.push(nova);
    return clone(nova);
  }
  if ((m = path.match(/^\/tarefas\/(\d+)\/itens\/all$/))) { tarefa(m[1]); return itensDa(Number(m[1])); }
  if (method === "POST" && (m = path.match(/^\/tarefas\/(\d+)\/iniciar$/))) {
    const t = tarefa(m[1]);
    if (t.status !== "Pendante") throw new Error("Somente tarefas pendentes podem ser iniciadas");
    t.status = "Em_Andamento";
    return { mensagem: "Tarefa iniciada", id: t.id, status: t.status };
  }
  if (method === "POST" && (m = path.match(/^\/tarefas\/(\d+)\/concluir$/))) {
    const t = tarefa(m[1]);
    if (t.status !== "Em_Andamento") throw new Error("A tarefa precisa estar em andamento para ser concluída");
    if (itensDa(t.id).some((i) => i.status !== "Conferido")) throw new Error("Ainda existem itens pendentes de conferência");
    t.status = "Concluida";
    return { mensagem: "Tarefa concluída", id: t.id, status: t.status };
  }
  if (method === "POST" && (m = path.match(/^\/tarefas\/(\d+)\/itens\/(\d+)\/conferir$/))) {
    const t = tarefa(m[1]);
    const v = D.vinculos[Number(m[2])];
    if (t.status !== "Em_Andamento") throw new Error("Inicie a tarefa antes de conferir itens");
    if (!v || v.t !== t.id) throw new Error("Item não pertence a esta tarefa");
    if (v.s === "Conferido") throw new Error("Item já conferido");
    v.s = "Conferido";
    return itensDa(t.id).find((i) => i.id === Number(m[2]));
  }
  if (method === "POST" && (m = path.match(/^\/tarefas\/(\d+)\/itens\/(\d+)$/))) {
    const t = tarefa(m[1]);
    if (D.vinculos[Number(m[2])]) throw new Error("Item já associado a uma tarefa");
    D.vinculos[Number(m[2])] = { t: t.id, s: "Pendente" };
    return itensDa(t.id).find((i) => i.id === Number(m[2]));
  }
  throw new Error("Modo teste: rota não simulada.");
}

async function api(path, { method = "GET", body } = {}) {
  if (S.demo) return apiDemo(path, method, body);
  const enviar = () => fetch(`${BASE_URL}${path}`, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${S.access || ""}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  let r;
  try { r = await enviar(); } catch { throw new Error(ERRO_REDE); }
  if (r.status === 401 && (await renovar())) {
    try { r = await enviar(); } catch { throw new Error(ERRO_REDE); }
  }
  if (r.status === 401) { S.onExpire?.(); throw new Error("Sessão expirada. Entre novamente."); }
  if (r.status === 204) return null;
  const data = await r.json().catch(() => null);
  if (!r.ok) throw new Error(msgErro(data, r.status));
  return data;
}

async function fazerLogin(ident, senha, lembrar) {
  let r;
  try {
    r = await fetch(`${BASE_URL}/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: ident.trim(), senha }),
    });
  } catch { throw new Error(ERRO_REDE); }
  const data = await r.json().catch(() => null);
  if (!r.ok) throw new Error(msgErro(data, r.status));
  S.remember = lembrar;
  await guardarTokens(data);
  if (lembrar) {
    await store.set(K.remember, "1");
    await store.set(K.login, ident.trim());
    await store.set(K.user, JSON.stringify(data.usuario));
  } else {
    await limparArmazenamento();
  }
  return data.usuario;
}

async function limparArmazenamento() {
  for (const k of Object.values(K)) await store.del(k);
}
async function encerrarSessao() {
  const refresh = S.refresh;
  S.access = null; S.refresh = null; S.remember = false; S.demo = false; S.demoUser = null;
  if (refresh) {
    fetch(`${BASE_URL}/logout`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refresh }),
    }).catch(() => {});
  }
  await limparArmazenamento();
}

/* ============================ UTILS ============================ */
const pad = (n) => String(n).padStart(2, "0");
const hojeISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const fmtData = (iso) => (iso ? iso.slice(0, 10).split("-").reverse().join("/") : "—");
const maskData = (t) => {
  const n = t.replace(/\D/g, "").slice(0, 8);
  if (n.length > 4) return `${n.slice(0, 2)}/${n.slice(2, 4)}/${n.slice(4)}`;
  if (n.length > 2) return `${n.slice(0, 2)}/${n.slice(2)}`;
  return n;
};
const isoDeBR = (txt) => {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(txt);
  if (!m) return null;
  const [, d, mo, y] = m.map(Number);
  const dt = new Date(y, mo - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
  return `${y}-${pad(mo)}-${pad(d)}`;
};
const ehAdmin = (u) => u?.perfil === "Admin" || u?.perfil === "Super Admin";
const iniciais = (nome = "") => nome.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join("") || "?";

function useLoad(fn, deps) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState("");
  const load = useCallback(async () => {
    setLoading(true); setErro("");
    try { setData(await fn()); } catch (e) { setErro(e.message); }
    setLoading(false);
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [load]);
  return { data, loading, erro, reload: load };
}

/* ============================ UI BÁSICA ============================ */
function Btn({ title, onPress, variant = "primary", icon, loading, disabled, style }) {
  const v = {
    primary: { bg: C.primary, fg: "#fff", bd: C.primary },
    ghost: { bg: C.surface, fg: C.text, bd: C.border },
    danger: { bg: C.dangerBg, fg: C.danger, bd: C.dangerBg },
  }[variant];
  return (
    <TouchableOpacity
      onPress={onPress} disabled={disabled || loading} activeOpacity={0.8}
      style={[s.btn, { backgroundColor: v.bg, borderColor: v.bd, opacity: disabled ? 0.5 : 1 }, style]}
    >
      {loading ? <ActivityIndicator color={v.fg} /> : (
        <View style={s.row}>
          {icon ? <Ionicons name={icon} size={18} color={v.fg} style={{ marginRight: 6 }} /> : null}
          <Text style={[s.btnTxt, { color: v.fg }]}>{title}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

function Field({ label, style, ...props }) {
  return (
    <View style={{ marginBottom: 16 }}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TextInput placeholderTextColor={C.dim} style={[s.input, style]} {...props} />
    </View>
  );
}

function Badge({ status }) {
  const st = STATUS[status] || { label: status, fg: C.muted, bg: C.surface };
  return (
    <View style={[s.badge, { backgroundColor: st.bg }]}>
      <Text style={{ color: st.fg, fontSize: 12, fontWeight: "600" }}>{st.label}</Text>
    </View>
  );
}

function ErroBox({ msg, onRetry }) {
  return (
    <View style={s.erroBox}>
      <Text style={{ color: C.danger, fontSize: 14 }}>{msg}</Text>
      {onRetry ? <TouchableOpacity onPress={onRetry}><Text style={{ color: C.primaryHi, marginTop: 8, fontWeight: "600" }}>Tentar de novo</Text></TouchableOpacity> : null}
    </View>
  );
}

function Popup({ data, onClose }) {
  useEffect(() => {
    if (!data?.auto) return undefined;
    const t = setTimeout(onClose, data.auto);
    return () => clearTimeout(t);
  }, [data]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!data) return null;
  const cor = data.tipo === "ok" ? C.ok : data.tipo === "erro" ? C.danger : C.warn;
  const icone = data.tipo === "ok" ? "checkmark-circle" : data.tipo === "erro" ? "close-circle" : "alert-circle";
  return (
    <Modal transparent animationType="fade" visible onRequestClose={onClose}>
      <View style={s.overlay}>
        <View style={s.popup}>
          <Ionicons name={icone} size={54} color={cor} />
          <Text style={s.popupTitle}>{data.titulo}</Text>
          {data.msg ? <Text style={s.popupMsg}>{data.msg}</Text> : null}
          <Btn title={data.botao || "OK"} onPress={onClose} variant="ghost" style={{ marginTop: 16, alignSelf: "stretch" }} />
        </View>
      </View>
    </Modal>
  );
}

function Body({ st, children, header }) {
  if (st.loading && !st.data) return <View style={s.center}><ActivityIndicator size="large" color={C.primary} /></View>;
  if (st.erro && !st.data) return <View style={{ padding: 20 }}><ErroBox msg={st.erro} onRetry={st.reload} /></View>;
  return (
    <ScrollView
      contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
      refreshControl={<RefreshControl refreshing={st.loading && !!st.data} onRefresh={st.reload} tintColor={C.primary} />}
    >
      {header}
      {st.erro ? <ErroBox msg={st.erro} /> : null}
      {children}
    </ScrollView>
  );
}

/* ============================ HEADER + DROPDOWN ============================ */
function Header({ title, canBack, onBack, onGo, onSair }) {
  const [aberto, setAberto] = useState(false);
  const insets = useSafeAreaInsets();
  const ir = (nome) => { setAberto(false); onGo(nome); };
  return (
    <View style={s.header}>
      <View style={{ width: 40 }}>
        {canBack ? <TouchableOpacity onPress={onBack} hitSlop={10}><Ionicons name="chevron-back" size={26} color={C.text} /></TouchableOpacity> : null}
      </View>
      <Text style={s.headerTitle} numberOfLines={1}>{title}</Text>
      <TouchableOpacity onPress={() => setAberto(true)} hitSlop={10} style={{ width: 40, alignItems: "flex-end" }}>
        <Ionicons name="ellipsis-vertical" size={24} color={C.text} />
      </TouchableOpacity>
      <Modal transparent animationType="fade" visible={aberto} onRequestClose={() => setAberto(false)}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={() => setAberto(false)}>
          <View style={[s.menu, { top: insets.top + 52 }]}>
            <MenuItem icon="time-outline" label="Histórico" onPress={() => ir("history")} />
            <MenuItem icon="person-outline" label="Perfil" onPress={() => ir("profile")} />
            <MenuItem icon="log-out-outline" label="Sair" cor={C.danger} onPress={() => { setAberto(false); onSair(); }} last />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}
function MenuItem({ icon, label, onPress, cor = C.text, last }) {
  return (
    <TouchableOpacity onPress={onPress} style={[s.menuItem, !last && { borderBottomWidth: 1, borderBottomColor: C.border }]}>
      <Ionicons name={icon} size={20} color={cor} />
      <Text style={{ color: cor, fontSize: 15, marginLeft: 12 }}>{label}</Text>
    </TouchableOpacity>
  );
}

/* ============================ 1ª TELA: LOGIN ============================ */
function Login({ prefill, onLogged }) {
  const [ident, setIdent] = useState(prefill.ident);
  const [senha, setSenha] = useState("");
  const [ver, setVer] = useState(false);
  const [lembrar, setLembrar] = useState(prefill.remember);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");

  const entrar = async () => {
    if (!ident.trim() || !senha) { setErro("Informe seu nome ou e-mail e a senha."); return; }
    setLoading(true); setErro("");
    try { onLogged(await fazerLogin(ident, senha, lembrar)); }
    catch (e) { setErro(e.message); setLoading(false); }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: "center", padding: 24 }} keyboardShouldPersistTaps="handled">
          <View style={{ alignItems: "center", marginBottom: 32 }}>
            <Ionicons name="cube-outline" size={72} color={C.primary} />
            <Text style={{ color: "#f6f6f6", fontSize: 34, fontWeight: "800", letterSpacing: 4 }}>ESTOK</Text>
            <Text style={[s.h2, { marginTop: 28 }]}>Faça login na sua conta</Text>
          </View>

          <Field label="Nome ou e-mail" value={ident} onChangeText={setIdent} autoCapitalize="none" autoCorrect={false}
            autoComplete="username" keyboardType="email-address" />
          <View style={{ marginBottom: 16 }}>
            <Text style={s.label}>Senha</Text>
            <View>
              <TextInput value={senha} onChangeText={setSenha} secureTextEntry={!ver} autoCapitalize="none"
                autoComplete="password" placeholderTextColor={C.dim} style={[s.input, { paddingRight: 44 }]} onSubmitEditing={entrar} />
              <TouchableOpacity onPress={() => setVer(!ver)} style={{ position: "absolute", right: 12, top: 12 }}>
                <Ionicons name={ver ? "eye-off-outline" : "eye-outline"} size={20} color={C.muted} />
              </TouchableOpacity>
            </View>
          </View>

          <View style={[s.row, { justifyContent: "space-between", marginBottom: 20 }]}>
            <Text style={{ color: C.soft, fontSize: 14 }}>Lembrar-me</Text>
            <Switch value={lembrar} onValueChange={setLembrar} trackColor={{ true: C.primary, false: "#374151" }} thumbColor="#fff" />
          </View>

          {erro ? <ErroBox msg={erro} /> : null}
          <Btn title="Entrar" onPress={entrar} loading={loading} />

          {MOSTRAR_DEMO ? (
            <View style={{ marginTop: 32 }}>
              <Text style={{ color: C.dim, fontSize: 12, textAlign: "center", marginBottom: 10, letterSpacing: 1 }}>MODO TESTE (SEM SERVIDOR)</Text>
              <View style={s.row}>
                <Btn title="Funcionário" icon="person" variant="ghost" onPress={() => onLogged(entrarDemo("Funcionario"))} style={{ flex: 1, marginRight: 6 }} />
                <Btn title="Admin" icon="shield-checkmark" variant="ghost" onPress={() => onLogged(entrarDemo("Admin"))} style={{ flex: 1, marginLeft: 6 }} />
              </View>
            </View>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

/* ============================ 2ª TELA: HOME ============================ */
function TarefaCard({ t, extra, children }) {
  const atrasada = t.status !== "Concluida" && t.prazo < hojeISO();
  return (
    <View style={s.card}>
      <View style={[s.row, { justifyContent: "space-between", alignItems: "flex-start" }]}>
        <Text style={s.cardTitle}>{t.titulo}</Text>
        <Badge status={t.status} />
      </View>
      {t.descricao ? <Text style={s.cardDesc}>{t.descricao}</Text> : null}
      <View style={[s.row, { marginTop: 10 }]}>
        <Ionicons name="calendar-outline" size={15} color={atrasada ? C.danger : C.muted} />
        <Text style={{ color: atrasada ? C.danger : C.muted, fontSize: 13, marginLeft: 6 }}>
          Prazo: {fmtData(t.prazo)}{atrasada ? " (atrasada)" : ""}
        </Text>
      </View>
      {extra}
      {children}
    </View>
  );
}

function HomeFuncionario({ go, tick }) {
  const st = useLoad(async () => {
    const todas = await api("/tarefas/all");
    const ordem = { Em_Andamento: 0, Pendante: 1 };
    return todas.filter((t) => t.status !== "Concluida").sort((a, b) => ordem[a.status] - ordem[b.status] || a.prazo.localeCompare(b.prazo));
  }, [tick]);
  const [busy, setBusy] = useState(null);
  const [popup, setPopup] = useState(null);

  const abrir = async (t) => {
    setBusy(t.id);
    try {
      if (t.status === "Pendante") await api(`/tarefas/${t.id}/iniciar`, { method: "POST" });
      go("scan", { tarefa: { ...t, status: "Em_Andamento" } });
    } catch (e) { setPopup({ tipo: "erro", titulo: "Não foi possível iniciar", msg: e.message }); }
    setBusy(null);
  };

  return (
    <>
      <Body st={st} header={<Text style={s.h2l}>Minhas tarefas</Text>}>
        {st.data?.length === 0 ? (
          <View style={s.vazio}><Ionicons name="checkmark-done-outline" size={42} color={C.dim} /><Text style={s.vazioTxt}>Nenhuma tarefa pendente para você.</Text></View>
        ) : null}
        {st.data?.map((t) => (
          <TarefaCard key={t.id} t={t}>
            <Btn
              title={t.status === "Pendante" ? "Iniciar" : "Continuar"} icon={t.status === "Pendante" ? "play" : "scan"}
              loading={busy === t.id} onPress={() => abrir(t)} style={{ marginTop: 14 }}
            />
          </TarefaCard>
        ))}
      </Body>
      <Popup data={popup} onClose={() => setPopup(null)} />
    </>
  );
}

function HomeAdmin({ go, tick }) {
  const st = useLoad(async () => {
    const [us, ts] = await Promise.all([api("/usuarios/all"), api("/tarefas/all")]);
    return { us, ts };
  }, [tick]);
  const { us = [], ts = [] } = st.data || {};
  const semResp = ts.filter((t) => t.id_usuario == null || !us.some((u) => u.id === t.id_usuario));

  return (
    <Body
      st={st}
      header={(
        <View style={{ marginBottom: 8 }}>
          <Text style={s.h2l}>Equipe e tarefas</Text>
          <Text style={{ color: C.muted, fontSize: 13, marginBottom: 14 }}>{ts.length} tarefas • {us.length} usuários</Text>
          <Btn title="Nova tarefa" icon="add" onPress={() => go("create")} style={{ marginBottom: 6 }} />
        </View>
      )}
    >
      {us.map((u) => {
        const minhas = ts.filter((t) => t.id_usuario === u.id);
        return (
          <View key={u.id} style={s.card}>
            <View style={s.row}>
              <View style={s.avatar}><Text style={s.avatarTxt}>{iniciais(u.nome)}</Text></View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={s.cardTitle}>{u.nome}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{u.email} • {u.perfil}</Text>
              </View>
              <Text style={{ color: C.primaryHi, fontWeight: "700" }}>{minhas.length}</Text>
            </View>
            {minhas.length === 0 ? <Text style={s.semTarefa}>Sem tarefas atribuídas</Text> : minhas.map((t) => <LinhaTarefa key={t.id} t={t} />)}
          </View>
        );
      })}
      {semResp.length > 0 ? (
        <View style={s.card}>
          <View style={s.row}>
            <View style={[s.avatar, { backgroundColor: C.surface }]}><Ionicons name="help" size={20} color={C.muted} /></View>
            <Text style={[s.cardTitle, { marginLeft: 12 }]}>Sem responsável</Text>
          </View>
          {semResp.map((t) => <LinhaTarefa key={t.id} t={t} />)}
        </View>
      ) : null}
    </Body>
  );
}
function LinhaTarefa({ t }) {
  const atrasada = t.status !== "Concluida" && t.prazo < hojeISO();
  return (
    <View style={s.linha}>
      <View style={{ flex: 1, paddingRight: 8 }}>
        <Text style={{ color: C.text, fontSize: 14 }} numberOfLines={1}>{t.titulo}</Text>
        <Text style={{ color: atrasada ? C.danger : C.muted, fontSize: 12, marginTop: 2 }}>Prazo: {fmtData(t.prazo)}</Text>
      </View>
      <Badge status={t.status} />
    </View>
  );
}

/* ============================ 3ª TELA (funcionário): SCANNER QR ============================ */
function Scan({ tarefa, back }) {
  const [perm, pedirPerm] = useCameraPermissions();
  const camRef = useRef(null);
  const lock = useRef(false);
  const [itens, setItens] = useState(null);
  const [erro, setErro] = useState("");
  const [popup, setPopup] = useState(null);
  const [fotos, setFotos] = useState([]);
  const [concluida, setConcluida] = useState(false);

  const carregar = useCallback(async () => {
    try { setItens(await api(`/tarefas/${tarefa.id}/itens/all`)); setErro(""); } catch (e) { setErro(e.message); }
  }, [tarefa.id]);
  useEffect(() => { carregar(); }, [carregar]);

  const total = itens?.length || 0;
  const feitos = itens?.filter((i) => i.status === "Conferido").length || 0;

  const mostrar = (p) => setPopup(p);
  const liberar = () => setTimeout(() => { lock.current = false; }, 2000);

  const aoLer = async ({ data }) => {
    if (lock.current || !itens || concluida) return;
    lock.current = true;
    try {
      const codigo = String(data).trim();
      const item = itens.find((i) => i.codigoUnico === codigo);
      if (!item) {
        mostrar({ tipo: "erro", titulo: "QR não reconhecido", msg: "Esse código não pertence aos itens desta tarefa.", auto: 2000 });
      } else if (item.status === "Conferido") {
        mostrar({ tipo: "aviso", titulo: "Item já conferido", msg: item.nome, auto: 2000 });
      } else {
        await api(`/tarefas/${tarefa.id}/itens/${item.id}/conferir`, { method: "POST" });
        const nova = itens.map((i) => (i.id === item.id ? { ...i, status: "Conferido" } : i));
        setItens(nova);
        if (nova.every((i) => i.status === "Conferido")) {
          await api(`/tarefas/${tarefa.id}/concluir`, { method: "POST" });
          setConcluida(true);
          mostrar({ tipo: "ok", titulo: "Item lido", msg: `“${item.nome}” foi lido.\n\nTodos os itens foram conferidos: tarefa concluída!`, botao: "Voltar às tarefas", fim: true });
        } else {
          mostrar({ tipo: "ok", titulo: "Item lido", msg: `“${item.nome}” foi lido.`, auto: 2000 });
        }
      }
    } catch (e) {
      mostrar({ tipo: "erro", titulo: "Não foi possível conferir", msg: e.message });
    }
    liberar();
  };

  const tirarFoto = async () => {
    try {
      const f = await camRef.current?.takePictureAsync({ quality: 0.5 });
      if (f?.uri) { setFotos((l) => [f.uri, ...l]); mostrar({ tipo: "ok", titulo: "Foto capturada", auto: 1200 }); }
    } catch (e) { mostrar({ tipo: "erro", titulo: "Erro ao tirar foto", msg: e.message }); }
  };

  const fecharPopup = () => { const fim = popup?.fim; setPopup(null); if (fim) back(); };
  const altura = Math.min(Dimensions.get("window").width * 1.05, 420);

  const camOk = !!perm?.granted;
  const simular = () => { const prox = itens?.find((i) => i.status !== "Conferido"); if (prox) aoLer({ data: prox.codigoUnico }); };

  return (
    <ScrollView contentContainerStyle={{ paddingBottom: 30 }}>
      <View style={{ height: altura, backgroundColor: "#000" }}>
        {camOk ? (
          <>
            <CameraView ref={camRef} style={{ flex: 1 }} facing="back" barcodeScannerSettings={{ barcodeTypes: ["qr"] }} onBarcodeScanned={aoLer} />
            <View pointerEvents="none" style={s.mira} />
          </>
        ) : (
          <View style={[s.center, { padding: 24 }]}>
            <Ionicons name="camera-outline" size={56} color={C.muted} />
            <Text style={[s.popupMsg, { marginVertical: 14 }]}>Precisamos da câmera para ler os QR Codes dos itens.</Text>
            {perm ? <Btn title="Permitir câmera" onPress={pedirPerm} /> : <ActivityIndicator color={C.primary} />}
          </View>
        )}
      </View>

      <View style={{ padding: 16 }}>
        <Text style={s.cardTitle}>{tarefa.titulo}</Text>
        <View style={[s.row, { justifyContent: "space-between", marginTop: 10 }]}>
          <Text style={{ color: C.muted, fontSize: 13 }}>{feitos} de {total} itens conferidos</Text>
          <Text style={{ color: C.primaryHi, fontSize: 13, fontWeight: "700" }}>{total ? Math.round((feitos * 100) / total) : 0}%</Text>
        </View>
        <View style={s.barra}><View style={[s.barraFill, { width: `${total ? (feitos * 100) / total : 0}%` }]} /></View>

        <Btn title="Tirar foto" icon="camera" variant="ghost" onPress={tirarFoto} disabled={!camOk} style={{ marginTop: 16 }} />
        {S.demo ? <Btn title="Simular leitura de QR (teste)" icon="flash" variant="ghost" onPress={simular} style={{ marginTop: 10 }} /> : null}
        {fotos.length > 0 ? (
          <ScrollView horizontal style={{ marginTop: 12 }} showsHorizontalScrollIndicator={false}>
            {fotos.map((u, i) => <Image key={u + i} source={{ uri: u }} style={s.foto} />)}
          </ScrollView>
        ) : null}

        {erro ? <View style={{ marginTop: 16 }}><ErroBox msg={erro} onRetry={carregar} /></View> : null}
        {itens && itens.length === 0 ? <Text style={[s.semTarefa, { marginTop: 16 }]}>Esta tarefa ainda não tem itens.</Text> : null}

        <Text style={[s.label, { marginTop: 22 }]}>Itens da tarefa</Text>
        {itens?.map((i) => {
          const ok = i.status === "Conferido";
          return (
            <View key={i.id} style={s.linhaItem}>
              <Ionicons name={ok ? "checkmark-circle" : "ellipse-outline"} size={22} color={ok ? C.ok : C.dim} />
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={{ color: ok ? C.muted : C.text, fontSize: 14, textDecorationLine: ok ? "line-through" : "none" }}>{i.nome}</Text>
                <Text style={{ color: C.dim, fontSize: 12 }}>{i.codigoUnico}</Text>
              </View>
            </View>
          );
        })}
      </View>
      <Popup data={popup} onClose={fecharPopup} />
    </ScrollView>
  );
}

/* ============================ 3ª TELA (admin): CRIAR TAREFA ============================ */
function CriarTarefa({ back }) {
  const st = useLoad(async () => {
    const [us, itens, locs, tarefas] = await Promise.all([
      api("/usuarios/all"), api("/itens/all"), api("/localizacoes/all"), api("/tarefas/all"),
    ]);

    const vinculados = new Set();
    (await Promise.all(tarefas.map((t) => api(`/tarefas/${t.id}/itens/all`).catch(() => [])))).flat().forEach((i) => vinculados.add(i.id));
    return {
      funcionarios: us.filter((u) => u.perfil === "Funcionario"),
      itens: itens.filter((i) => !vinculados.has(i.id)),
      locais: Object.fromEntries(locs.map((l) => [l.id, l.nome])),
    };
  }, []);
  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [prazo, setPrazo] = useState("");
  const [resp, setResp] = useState(null);
  const [sel, setSel] = useState({});
  const [busca, setBusca] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [popup, setPopup] = useState(null);

  const { funcionarios = [], itens = [], locais = {} } = st.data || {};
  const filtrados = itens.filter((i) => `${i.nome} ${i.codigoUnico}`.toLowerCase().includes(busca.toLowerCase()));
  const qtd = Object.values(sel).filter(Boolean).length;

  const criar = async () => {
    const iso = isoDeBR(prazo);
    if (!titulo.trim()) return setPopup({ tipo: "aviso", titulo: "Informe o título" });
    if (!iso) return setPopup({ tipo: "aviso", titulo: "Prazo inválido", msg: "Use o formato DD/MM/AAAA." });
    if (iso < hojeISO()) return setPopup({ tipo: "aviso", titulo: "Prazo no passado", msg: "Escolha uma data de hoje em diante." });
    if (!resp) return setPopup({ tipo: "aviso", titulo: "Escolha o funcionário responsável" });
    if (qtd === 0) return setPopup({ tipo: "aviso", titulo: "Selecione ao menos um item", msg: "Sem itens o funcionário não tem o que conferir." });
    setSalvando(true);
    let criada = null;
    try {
      criada = await api("/tarefas", { method: "POST", body: { titulo: titulo.trim(), descricao: descricao.trim() || null, prazo: iso, status: "Pendante", id_usuario: resp } });
      for (const id of Object.keys(sel).filter((k) => sel[k])) {
        await api(`/tarefas/${criada.id}/itens/${id}`, { method: "POST" });
      }
      setPopup({ tipo: "ok", titulo: "Tarefa criada", msg: `“${criada.titulo}” foi atribuída com ${qtd} item(ns).`, fim: true });
    } catch (e) {
      setPopup({ tipo: "erro", titulo: criada ? "Tarefa criada, mas faltaram itens" : "Não foi possível criar", msg: e.message, fim: !!criada });
    }
    setSalvando(false);
  };
  const fechar = () => { const fim = popup?.fim; setPopup(null); if (fim) back(); };

  return (
    <>
      <Body st={st}>
        <Field label="Título" value={titulo} onChangeText={setTitulo} placeholder="Ex.: Conferir estoque do almoxarifado" maxLength={255} />
        <Field label="Descrição (opcional)" value={descricao} onChangeText={setDescricao} placeholder="Ex.: Contagem mensal" maxLength={255} multiline />
        <Field label="Prazo" value={prazo} onChangeText={(t) => setPrazo(maskData(t))} placeholder="DD/MM/AAAA" keyboardType="number-pad" maxLength={10} />

        <Text style={s.label}>Responsável</Text>
        {funcionarios.length === 0 ? <Text style={s.semTarefa}>Nenhum funcionário cadastrado.</Text> : null}
        {funcionarios.map((u) => {
          const on = resp === u.id;
          return (
            <TouchableOpacity key={u.id} onPress={() => setResp(u.id)} style={[s.opcao, on && s.opcaoOn]}>
              <Ionicons name={on ? "radio-button-on" : "radio-button-off"} size={20} color={on ? C.primaryHi : C.dim} />
              <View style={{ marginLeft: 10, flex: 1 }}>
                <Text style={{ color: C.text, fontSize: 14 }}>{u.nome}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{u.email}</Text>
              </View>
            </TouchableOpacity>
          );
        })}

        <Text style={[s.label, { marginTop: 18 }]}>Itens da tarefa ({qtd} selecionado{qtd === 1 ? "" : "s"})</Text>
        <TextInput value={busca} onChangeText={setBusca} placeholder="Buscar item ou código" placeholderTextColor={C.dim} style={[s.input, { marginBottom: 10 }]} />
        {itens.length === 0 ? <Text style={s.semTarefa}>Não há itens livres para vincular.</Text> : null}
        {filtrados.map((i) => {
          const on = !!sel[i.id];
          return (
            <TouchableOpacity key={i.id} onPress={() => setSel((o) => ({ ...o, [i.id]: !o[i.id] }))} style={[s.opcao, on && s.opcaoOn]}>
              <Ionicons name={on ? "checkbox" : "square-outline"} size={22} color={on ? C.primaryHi : C.dim} />
              <View style={{ marginLeft: 10, flex: 1 }}>
                <Text style={{ color: C.text, fontSize: 14 }}>{i.nome}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{i.codigoUnico}{i.id_localizacao && locais[i.id_localizacao] ? ` • ${locais[i.id_localizacao]}` : ""}</Text>
              </View>
            </TouchableOpacity>
          );
        })}

        <Btn title="Criar tarefa" icon="checkmark" onPress={criar} loading={salvando} style={{ marginTop: 22 }} />
      </Body>
      <Popup data={popup} onClose={fechar} />
    </>
  );
}

/* ============================ HISTÓRICO e PERFIL ============================ */
function Historico({ user, tick }) {
  const adm = ehAdmin(user);
  const st = useLoad(async () => {
    const [ts, us] = await Promise.all([api("/tarefas/all"), adm ? api("/usuarios/all") : Promise.resolve([])]);
    return { ts: ts.filter((t) => t.status === "Concluida").sort((a, b) => b.id - a.id), nomes: Object.fromEntries(us.map((u) => [u.id, u.nome])) };
  }, [tick, adm]);
  return (
    <Body st={st} header={<Text style={s.h2l}>Tarefas concluídas</Text>}>
      {st.data?.ts.length === 0 ? <View style={s.vazio}><Ionicons name="time-outline" size={42} color={C.dim} /><Text style={s.vazioTxt}>Nada concluído ainda.</Text></View> : null}
      {st.data?.ts.map((t) => (
        <TarefaCard key={t.id} t={t} extra={adm ? <Text style={{ color: C.muted, fontSize: 13, marginTop: 6 }}>Responsável: {st.data.nomes[t.id_usuario] || "—"}</Text> : null} />
      ))}
    </Body>
  );
}

function Perfil({ user }) {
  const linha = (icone, rotulo, valor) => (
    <View style={s.linhaPerfil}>
      <Ionicons name={icone} size={20} color={C.primaryHi} />
      <View style={{ marginLeft: 12 }}>
        <Text style={{ color: C.muted, fontSize: 12 }}>{rotulo}</Text>
        <Text style={{ color: C.text, fontSize: 15 }}>{valor}</Text>
      </View>
    </View>
  );
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <View style={{ alignItems: "center", marginVertical: 24 }}>
        <View style={[s.avatar, { width: 84, height: 84, borderRadius: 42 }]}><Text style={[s.avatarTxt, { fontSize: 30 }]}>{iniciais(user.nome)}</Text></View>
        <Text style={[s.h2, { marginTop: 14 }]}>{user.nome}</Text>
      </View>
      <View style={s.card}>
        {linha("mail-outline", "E-mail", user.email)}
        {linha("shield-checkmark-outline", "Perfil", user.perfil)}
        {linha("finger-print-outline", "ID", String(user.id))}
      </View>
    </ScrollView>
  );
}

/* ============================ RAIZ / NAVEGAÇÃO ============================ */
function Root() {
  const [boot, setBoot] = useState(true);
  const [user, setUser] = useState(null);
  const [prefill, setPrefill] = useState({ ident: "", remember: false });
  const [stack, setStack] = useState([{ name: "home" }]);
  const [tick, setTick] = useState(0); 

  const reset = useCallback(() => { setStack([{ name: "home" }]); setTick((t) => t + 1); }, []);
  const go = useCallback((name, params = {}) => setStack((p) => [...p, { name, params }]), []);
  const back = useCallback(() => { setStack((p) => (p.length > 1 ? p.slice(0, -1) : p)); setTick((t) => t + 1); }, []);
  const sair = useCallback(async () => { await encerrarSessao(); setUser(null); reset(); }, [reset]);

  useEffect(() => { S.onExpire = () => { setUser(null); reset(); }; }, [reset]);

  // Login automático quando "lembrar-me" estava marcado.
  useEffect(() => {
    (async () => {
      const remember = (await store.get(K.remember)) === "1";
      setPrefill({ ident: (await store.get(K.login)) || "", remember });
      if (remember) {
        const refresh = await store.get(K.refresh);
        const salvo = await store.get(K.user);
        if (refresh && salvo) {
          S.refresh = refresh; S.remember = true;
          if (await renovar()) { try { setUser(JSON.parse(salvo)); } catch {} }
          else { S.refresh = null; S.remember = false; await limparArmazenamento(); }
        }
      }
      setBoot(false);
    })();
  }, []);

  useEffect(() => {
    if (Platform.OS === "web") return undefined;
    const sub = BackHandler.addEventListener("hardwareBackPress", () => {
      if (user && stack.length > 1) { back(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [user, stack.length, back]);

  if (boot) return <View style={[s.center, { backgroundColor: C.bg }]}><ActivityIndicator size="large" color={C.primary} /></View>;
  if (!user) return <Login prefill={prefill} onLogged={(u) => { setUser(u); reset(); }} />;

  const adm = ehAdmin(user);
  const atual = stack[stack.length - 1];
  const titulos = { home: adm ? "Painel" : "Minhas tarefas", scan: "Conferência", create: "Nova tarefa", history: "Histórico", profile: "Perfil" };
  let tela = null;
  if (atual.name === "home") tela = adm ? <HomeAdmin go={go} tick={tick} /> : <HomeFuncionario go={go} tick={tick} />;
  if (atual.name === "scan") tela = <Scan key={atual.params.tarefa.id} tarefa={atual.params.tarefa} back={back} />;
  if (atual.name === "create") tela = <CriarTarefa back={back} />;
  if (atual.name === "history") tela = <Historico user={user} tick={tick} />;
  if (atual.name === "profile") tela = <Perfil user={user} />;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }} edges={["top", "bottom"]}>
      <Header
        title={titulos[atual.name]} canBack={stack.length > 1} onBack={back}
        onGo={(n) => (atual.name === n ? null : go(n))} onSair={sair}
      />
      {S.demo ? <View style={s.demoBar}><Text style={{ color: C.warn, fontSize: 12, fontWeight: "600" }}>MODO TESTE — dados fictícios, nada é salvo no banco</Text></View> : null}
      <View style={{ flex: 1 }}>{tela}</View>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <Root />
    </SafeAreaProvider>
  );
}

/* ============================ ESTILOS ============================ */
const s = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center" },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  h2: { color: "#fff", fontSize: 22, fontWeight: "700", textAlign: "center" },
  h2l: { color: "#fff", fontSize: 22, fontWeight: "700", marginBottom: 4 },
  label: { color: "#f3f4f6", fontSize: 14, fontWeight: "500", marginBottom: 8 },
  input: {
    backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 10, color: "#fff", fontSize: 15,
  },
  btn: { borderRadius: 8, borderWidth: 1, paddingVertical: 12, paddingHorizontal: 16, alignItems: "center", justifyContent: "center" },
  btnTxt: { fontSize: 15, fontWeight: "600" },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  erroBox: { backgroundColor: C.dangerBg, borderRadius: 8, padding: 12, marginBottom: 16 },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between", height: 52,
    paddingHorizontal: 14, backgroundColor: C.bg2, borderBottomWidth: 1, borderBottomColor: C.border,
  },
  headerTitle: { color: "#fff", fontSize: 17, fontWeight: "700", flex: 1, textAlign: "center" },
  menu: {
    position: "absolute", right: 12, minWidth: 180, backgroundColor: "#1f2937", borderRadius: 10,
    borderWidth: 1, borderColor: C.border, elevation: 10, shadowColor: "#000", shadowOpacity: 0.4, shadowRadius: 12,
  },
  menuItem: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14 },
  card: { backgroundColor: C.surface, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 14, marginTop: 12 },
  cardTitle: { color: "#fff", fontSize: 16, fontWeight: "600", flex: 1, paddingRight: 8 },
  cardDesc: { color: C.muted, fontSize: 14, marginTop: 6 },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: C.primaryBg, alignItems: "center", justifyContent: "center" },
  avatarTxt: { color: C.primaryHi, fontWeight: "700", fontSize: 15 },
  linha: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.border, marginTop: 10 },
  semTarefa: { color: C.dim, fontSize: 13, marginTop: 10 },
  vazio: { alignItems: "center", paddingVertical: 50 },
  vazioTxt: { color: C.muted, marginTop: 10, fontSize: 14 },
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", alignItems: "center", justifyContent: "center", padding: 28 },
  popup: { backgroundColor: "#1f2937", borderRadius: 16, padding: 22, alignItems: "center", width: "100%", maxWidth: 340, borderWidth: 1, borderColor: C.border },
  popupTitle: { color: "#fff", fontSize: 18, fontWeight: "700", marginTop: 10, textAlign: "center" },
  popupMsg: { color: C.soft, fontSize: 14, marginTop: 8, textAlign: "center", lineHeight: 20 },
  mira: { position: "absolute", top: "50%", left: "50%", width: 210, height: 210, marginTop: -105, marginLeft: -105, borderWidth: 3, borderColor: C.primaryHi, borderRadius: 18 },
  barra: { height: 8, backgroundColor: C.surface, borderRadius: 4, marginTop: 8, overflow: "hidden" },
  barraFill: { height: 8, backgroundColor: C.primary, borderRadius: 4 },
  foto: { width: 64, height: 64, borderRadius: 8, marginRight: 8 },
  linhaItem: { flexDirection: "row", alignItems: "center", paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border },
  opcao: { flexDirection: "row", alignItems: "center", padding: 12, borderRadius: 10, borderWidth: 1, borderColor: C.border, backgroundColor: C.surface, marginBottom: 8 },
  opcaoOn: { borderColor: C.primary, backgroundColor: C.primaryBg },
  demoBar: { backgroundColor: "rgba(251,191,36,0.12)", paddingVertical: 5, alignItems: "center" },
  linhaPerfil: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
});